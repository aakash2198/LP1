#include <iostream>
#include <omp.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
using namespace std;


void BubbleSerial(int a[],int n)
{

	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if(a[j]>a[j+1])
			{
				int temp = a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}

}



void BubbleParallel(int a[],int n)
{
	int start=0;
	for(int i=0;i<n-1;i++)
	{
		start=i%2;
		#pragma omp parallel for default(none) shared(a,start,n)
				for(int j=start;j<n-1;j=j+2)
				{
					if(a[j]>a[j+1])
					{
						int temp = a[j];
						a[j]=a[j+1];
						a[j+1]=temp;
					}
				}		
	}
}


int main()
{
	int n=10000;

	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		a[i]=rand()%n;
		b[i]=a[i];
	}

	double startTime,endTime;

	startTime = omp_get_wtime();
	BubbleSerial(a,n);
	endTime = omp_get_wtime();
	cout<<"\nTime taken "<<endTime - startTime;
	cout<<"\n For serial execution --";
	for(int i=0;i<n;i++)
	{
		cout<<" "<<a[i];
	}


	startTime = omp_get_wtime();
	BubbleParallel(b,n);
	endTime = omp_get_wtime();
	cout<<"\nTime taken "<<endTime - startTime;
	cout<<"\n For parallel execution --";
	for(int i=0;i<n;i++)
	{
		cout<<" "<<b[i];
	}



	return 0;
}