#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include<omp.h>
#include<time.h>
#include<math.h>
#include<malloc.h>
#include<bits/stdc++.h>

using namespace std;






void merge(int a[],int n,int temp[])
{

	/*int m=start1;
	int n=start2;
	int k=0;
	int temp[2000];

	while(m<=end1 && n<=end2)
	{
		if(a[m]>a[n])
		{
			temp[k]=a[n++];
		}
		else
		{
			temp[k]=a[m++];
		}
		k++;
	}

	while(m<=end1)
	{
		temp[k++]=a[m++];
	}
 
	while(n<=end2)                            //check it
	{
		temp[k++]=a[n++];
	}

	int i;
	for(i=start1,k=0;i<end2;i++,k++)
	{
		a[i]=temp[k];
	}*/


	int i=0,j=n/2,k=0;
	int start=0,mid=n/2;

	while(i<mid && j<n)
	{
		if(a[i]>a[j])
		{
			temp[k]=a[j++];
		}
		else
		{
			temp[k]=a[i++];
		}
		k++;
	}

	while(i<mid)
	{
		temp[k++]=a[i++];
	}
 
	while(j<n)                            //check it
	{
		temp[k++]=a[j++];
	}

	memcpy(a,temp, n*sizeof(int) ) ;
	//memcpy(X, tmp, n*sizeof(int));


}

void mergeParallel(int a[],int n,int temp[])
{
	if(n<2)
			return;

		#pragma omp parallel sections            // sections    <<<<<< s is imp
		{
			#pragma omp section
				mergeParallel(a,n/2,temp);

			#pragma omp section	
			mergeParallel(a+n/2,n-n/2,temp+n/2);       // ***** imp temp+n/2
		}

		#pragma omp taskwait
		merge(a,n,temp);
		
}


void mergeSerially(int a[],int n,int temp[])
{
	/*int mid;
	if(start<end)
	{
		mid=(start+end)/2;
		mergeSerially(a,start,mid);
		mergeSerially(a,mid+1,end);
		merge(a,start,mid,mid+1,end);
	}*/
	if(n<2)
		return ;

	mergeSerially(a,n/2,temp);
	mergeSerially(a+n/2,n-n/2,temp);

	merge(a,n,temp);

}


int main()
{
	int n=100000;
	int a[n],b[n],temp[n];

	for(int i=0;i<n;i++)
	{
		a[i]=rand()%n;
		b[i]=a[i];
	}


	double startTime,endTime;

	startTime = omp_get_wtime();
	mergeSerially(a,n,temp);
	endTime = omp_get_wtime();
	cout<<"\nTime taken "<<endTime - startTime +0.1;
	cout<<"\n For serial execution --";
	for(int i=0;i<n;i++)
	{
		cout<<" "<<a[i];
	}


	startTime = omp_get_wtime();
	mergeParallel(b,n,temp);
	endTime = omp_get_wtime();
	cout<<"\nTime taken "<<endTime - startTime;
	cout<<"\n For parallel execution --";
	for(int i=0;i<n;i++)
	{
		cout<<" "<<b[i];
	}
}
