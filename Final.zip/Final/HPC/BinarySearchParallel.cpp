#include<iostream>
#include<mpi/mpi.h>
#include<bits/stdc++.h>

using namespace std;


void BinarySearch(int arr[],int start,int end,int key,int rank)
{
	int mid;
	while(start<=end)
	{
		mid=(start+end)/2;

		if(arr[mid]==key)
		{
			cout<<key<<" Element found at"<<mid<<"position  by rank "<<rank<<endl;
			return;
		}
		else if(arr[mid]<key)
		{
			start=mid+1;
		}
		else
		{
			end=mid-1;
		}

	}
}


int main(int argc,char **argv)
{
	int n=1000;
	

	int *arr = (int *)malloc(sizeof(int)*n);
	for(int i=0;i<n;i++)
	{
		arr[i]=i+1;
	}

	MPI_Init(&argc,&argv);

	int size,rank;

	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);

	int blockdiv = n/size;
	int key=99;
	
	if(rank==0)
	{
		double starttime = MPI_Wtime();
		BinarySearch(arr,rank*blockdiv,(rank+1)*blockdiv-1,key,rank);
		double endtime = MPI_Wtime();
		cout<<"\n Execution time for rank "<<rank<<" is"<<(endtime-starttime)*1000<<endl;
	}
	else if(rank==1)
	{
		double starttime = MPI_Wtime();
		BinarySearch(arr,rank*blockdiv,(rank+1)*blockdiv-1,key,rank);
		double endtime = MPI_Wtime();
		cout<<"\n Execution time for rank "<<rank<<" is"<<(endtime-starttime)*1000<<endl;
	}
	else if(rank==2)
	{
		double starttime = MPI_Wtime();
		BinarySearch(arr,rank*blockdiv,(rank+1)*blockdiv-1,key,rank);
		double endtime = MPI_Wtime();
		cout<<"\n Execution time for rank "<<rank<<" is"<<(endtime-starttime)*1000<<endl;
	}
	else if(rank==3)
	{
		double starttime = MPI_Wtime();
		BinarySearch(arr,rank*blockdiv,(rank+1)*blockdiv-1,key,rank);
		double endtime = MPI_Wtime();
		cout<<"\n Execution time for rank "<<rank<<" is"<<(endtime-starttime)*1000<<endl;
	}
		

	MPI_Finalize();
	
	return 0;
}
