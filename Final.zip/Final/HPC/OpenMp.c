#include<stdio.h>
#include<omp.h>

int main()
{
	int numT;
	int Tid;
	#pragma omp parallel 
	{
		numT = omp_get_num_threads();
		Tid = omp_get_thread_num();

		printf("Hello world by %d , out of %d ",Tid,numT);
	}

	printf("\n byee");

	return 0;
}