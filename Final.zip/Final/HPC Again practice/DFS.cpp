#include <iostream>
#include<bits/stdc++.h>
#include<omp.h>

using namespace std;

class Node
{
public:
	int key;
	Node* left;
	Node *right;

	 Node(int d)
	{
		key=d;
	}
}

void insert(Node *node,int key)
{
	
  
    /* Otherwise, recur down the tree */
    if (key < node->key) 
        node->left  = insert(node->left, key); 
    else if (key > node->key) 
        node->right = insert(node->right, key);    
  
    /* return the (unchanged) node pointer */
    
}



void inorder( Node *root) 
{ 
    if (root != NULL) 
    { 
        inorder(root->left); 
        printf("%d \n", root->key); 
        inorder(root->right); 
    } 
} 


int main()
{
	Node *root=null;
	if (node == NULL) 
		{
			Node *temp=new Node(key);
			temp->left=null;
			temp->right=null;

			
		}
		root=temp;
	insert(root,10);

	int N;
	cout<<"\nEnter N";
	cin>>N;
	for(int i=0;i<N;i++)
	{
		int data=rand()%N;
		insert(root,data);
	}


	inorder(root);




	return 0;
}