#include<iostream>
#include<bits/stdc++.h>
#include<omp.h>

using namespace std;


void bubbleSearial(int a[],int n)
{
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if(a[j+1]<a[j])
			{
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
}

void bubbleParallel(int a[],int n)
{
	int start=0;
	for(int i=0;i<n-1;i++)
	{
		start=i%2;

	#pragma omp parallel for default(none) shared(a,start,n)
		for(int j=start;j<n-1;j=j+2)
		{
			if(a[j+1]<a[j])
			{
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}

	}
}




int main()
{
	int n;
	cin>>n;

	int arr1[n];
	int arr2[n];
	for(int i=0;i<n;i++)
	{
		arr1[i]=rand()%n;
		arr2[i]=rand()%n;
	}

	cout<<"\nFor serial **************";
	double time1 = omp_get_wtime();
	bubbleSearial(arr1,n);
	double time2 = omp_get_wtime();
	cout<<"\nTime is "<<(double)(time2-time1);

	for(int i=0;i<n;i++)
	{
		cout<<" "<<arr1[i];
	}


	cout<<"\nFor parallel **************";
	 time1 = omp_get_wtime();
	bubbleSearial(arr2,n);
	 time2 = omp_get_wtime();
	cout<<"\nTime is "<<(double)time2-time1;

	for(int i=0;i<n;i++)
	{
		cout<<" "<<arr1[i];
	}




	return 0;
}