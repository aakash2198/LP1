#include<iostream>
#include<bits/stdc++.h>
#include<omp.h>

using namespace std;


void merge(int a[],int i1,int j1,int i2,int j2)
{
	int temp[j2-i1+1];
	int k=0;
	int a1=i1;
	int b1=i2;
	while(a1<=j1 && b1<=j2)
	{
		if(a[a1]>a[b1])
		{
			temp[k++]=a[b1++];
		}
		else
		{
			temp[k++]=a[a1++];
		}
	}

	while(a1<=j1)
	{
		temp[k++]=a[a1++];
	}

	while(b1<=j2)
	{
		temp[k++]=a[b1++];
	}

	k=0;
	for(int i=i1;i<=j2;i++)
	{
		a[i]=temp[k++];
	}


}


void merger(int a[],int start,int end)
{
	int mid;
	if(start<end)
	{
		mid=(start+end)/2;

		merger(a,start,mid);
		merger(a,mid+1,end);

		merge(a,start,mid,mid+1,end);
	}
}



void Parallelmerger(int a[],int start,int end)
{
	int mid;
	if(start<end)
	{
		mid=(start+end)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				merger(a,start,mid);	
			}

			#pragma omp section
			{
				merger(a,mid+1,end);
			}
		}
		
		
		merge(a,start,mid,mid+1,end);
	}
}



int main()
{

	int n;
	cin>>n;

	int arr1[n];
	int arr2[n];
	for(int i=0;i<n;i++)
	{
		arr1[i]=rand()%n;
		arr2[i]=rand()%n;
	}

	cout<<"\nFor serial **************";
	double time1 = omp_get_wtime();
	merger(arr1,0,n);
	double time2 = omp_get_wtime();
	cout<<"\nTime is "<<(double)(time2-time1);

	for(int i=0;i<n;i++)
	{
		cout<<" "<<arr1[i];
	}



	cout<<"\nFor parallel **************";
	 time1 = omp_get_wtime();
	Parallelmerger(arr2,0,n);
	 time2 = omp_get_wtime();
	cout<<"\nTime is "<<(double)time2-time1;

	for(int i=0;i<n;i++)
	{
		cout<<" "<<arr1[i];
	}


	return 0;
}