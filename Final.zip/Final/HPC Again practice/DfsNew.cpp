#include <iostream>
#include<bits/stdc++.h>
#include<omp.h>

using namespace std;

class Node
{
public:
	int key;
	Node* left;
	Node *right;

	 Node(int d)
	{
		key=d;
		left=NULL;
		right=NULL;
	}
};


void postorder(Node *node)
{
	if(node!=NULL)
	{
		postorder(node->left);
		postorder(node->right);

		cout<<" "<<node->key;
	}
}


void Parallelpostorder(Node *node)
{
	if(node!=NULL)
	{
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				postorder(node->left);
			}
			#pragma omp section
			{
				postorder(node->right);
			}
		}
		#pragma omp waittask
		cout<<" "<<node->key;
	}
}


int main()
{
	Node *root=new Node(10);
	root->left=new Node(8);
	root->right = new Node(3);
	root->left->left = new Node(4);
	root->left->right = new Node(5);

	postorder(root);

	cout<<endl;

	Parallelpostorder(root);



	return 0;
}