package MyP;

public class State {
	int arr[]=new int[9];
	int h;
	int gn;
	int fn;
	
	public State(State s1)
	{
		int arr[]=new int[9];
		for(int i=0;i<9;i++)
		{
			this.arr[i]=s1.arr[i];
		}
	}
	
	public State()
	{
		gn=0;
		fn=0;
		h=0;
	}

}
