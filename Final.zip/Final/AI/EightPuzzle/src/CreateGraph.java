import java.util.*;
import java.io.*;
import java.lang.*;


public class CreateGraph {

	List<GraphBean> Graphqueue = new ArrayList<GraphBean>();
	GraphBean goalState = new GraphBean();
	Scanner sc=new Scanner(System.in);
	
	public int[][] acceptInput()
	{
		int g[][]= new int[3][3];       //Remeber this 3 * 3
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				g[i][j]=sc.nextInt();
			}
		}
		
		return g;
	}
	
	public void genrateData()
	{
		GraphBean g1 = new GraphBean();
		System.out.println("Enter initial State ");
		g1.state = acceptInput();                       // remember this we want state
		System.out.println("Enter Goal State ");
		goalState.state = acceptInput();
		Graphqueue.add(g1);
		
		System.out.println("Initial State");
		System.out.println();
		g1.state.toString();
		
		System.out.println("Goal State");
		System.out.println();
		goalState.state.toString();
		
		
	}
	
	public void goToAstar()
	{
		AStar a = new AStar();
		a.getInput(Graphqueue, goalState);
		
	}
	
	
}
