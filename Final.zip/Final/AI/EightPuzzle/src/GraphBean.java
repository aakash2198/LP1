import java.util.*;
import java.io.*;
import java.lang.*;


public class GraphBean {
	
	int state[][]=new int[3][3];
	int fn;
	int gn;  //depth
	int hn; 
	
	public GraphBean()
	{
		fn=0;
		gn=0;
		hn=0;
	}

	@Override
	public String toString() {
		
		String str = new  String("");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				str += ("\t" + state[i][j]);
			}
			str += "\n";
		}
		return str;
	}

	
}
