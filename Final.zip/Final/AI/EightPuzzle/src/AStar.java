import java.util.*;
import java.io.*;
import java.lang.*;


public class AStar {
	
	List<GraphBean> Graphqueue = new ArrayList<GraphBean>();
	GraphBean goalState = new GraphBean();
	//Scanner sc=new Scanner(System.in);
	int Heuristic[]=new int[4];
	int i;
	int step;
	
	public void getInput(List<GraphBean> gq , GraphBean gs)
	{
		Graphqueue=gq;
		goalState = gs;
		i=1;
		while(!isFinal())
		{
			System.out.println("******* Iteration "+i+" **********");
			Algo(i);
			i++;	
		}
		
		
	}
	
	public boolean isFinal() {
		// TODO Auto-generated method stub
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if( Graphqueue.get(Graphqueue.size()-1).state[i][j] != goalState.state[i][j])  
				{
					return false;
				}
			}
		}
		
		return true;
	}

	public void Algo(int i2) {
		// TODO Auto-generated method stub
		int p=0;
		int g[][]= new int[3][3];
		step=i2; // g of n
		
		g = genarateTemplate();
		g = moveLeft(g);
		Heuristic[0] = calHeuristic(g);                                  // 0
		disPlayMove(g);
		
		g = genarateTemplate();
		g = moveRight(g);
		Heuristic[1] = calHeuristic(g);                                  // 1 
		disPlayMove(g);
		
		g = genarateTemplate();
		g = moveUp(g);
		Heuristic[2] = calHeuristic(g);                                    //2
		disPlayMove(g);
		
		g = genarateTemplate();
		g = moveDown(g);
		Heuristic[3] = calHeuristic(g);						//3
		disPlayMove(g);
		
		int min=0;
		for(int i=0;i<4;i++)
		{
			if(Heuristic[i]<Heuristic[min])
			{
				min=i;
			}
		}
		
		
		if(min==0)
		{
			//System.out.println("Selected is ");
			g = genarateTemplate();
			g = moveLeft(g);
			
		}
		else if(min==1)
		{
			//System.out.println("Selected is ");
			g = genarateTemplate();
			g = moveRight(g);
		}
		else if(min==2)
		{
			//System.out.println("Selected is ");
			g = genarateTemplate();
			g = moveUp(g);
		}
		else
		{
			//System.out.println("Selected is ");
			g = genarateTemplate();
			g = moveDown(g);
		}
		
		System.out.println("***** Seleted is _____****____");
		Graphqueue.add(disPlayMove(g));
		
	}

	

	public GraphBean disPlayMove(int[][] g) {
		// TODO Auto-generated method stub
		
		GraphBean g1 =new GraphBean();
		g1.state=g;
		g1.gn=step;
		g1.hn=calHeuristic(g);
		g1.fn = g1.gn+ g1.hn;
		
		System.out.println("** **"+g1.toString());
		System.out.println("fn is "+g1.fn+" gn is "+g1.gn+" hn is "+g1.hn);
		
		
		return g1;
	}

	public int[][] moveLeft(int[][] g) {
		// TODO Auto-generated method stub
		
		int temp;
		int flag=1;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(g[i][j]==0 && j!=0)
				{
					temp=g[i][j];
					g[i][j]=g[i][j-1];
					g[i][j-1]=temp;
					flag=0;
					break;                               // here break is imp
				} 
			}
			
			if(flag==0)
				break;
		}
		
		
		return g;                  // return g is imp
	}
	
	
	
	public int[][] moveRight(int[][] g) {
		// TODO Auto-generated method stub
		
		int temp;
		int flag=1;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(g[i][j]==0 && j!=2)
				{
					temp=g[i][j];
					g[i][j]=g[i][j+1];
					g[i][j+1]=temp;
					flag=0;
					break;           // here break is imp
				}
			}
			
			if(flag==0)
				break;
		}
		
		
		return g;
	}
	
	
	public int[][] moveUp(int[][] g) {
		// TODO Auto-generated method stub
		
		int temp;
		int flag=1;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(g[i][j]==0 && i!=0)
				{
					temp=g[i][j];
					g[i][j]=g[i-1][j];
					g[i-1][j]=temp;
					flag=0;
					break;
				}
			}
			
			if(flag==0)
				break;
		}
		
		
		return g;
	}
	
	
	
	public int[][] moveDown(int[][] g) {
		// TODO Auto-generated method stub
		
		int temp;
		int flag=1;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(g[i][j]==0 && i!=2)
				{
					temp=g[i][j];
					g[i][j]=g[i+1][j];
					g[i+1][j]=temp;
					flag=0;
					break;
				}
			}
			
			if(flag==0)
				break;
		}
		
		
		return g;
	}

	public int[][] genarateTemplate() {
		// TODO Auto-generated method stub
			
		int g2[][]= new int[3][3];
			for(int i=0;i<3;i++)
			{
				for(int j=0;j<3;j++)
				{
					g2[i][j]=Graphqueue.get(Graphqueue.size()-1).state[i][j];
					//System.out.println("okay "+g2[i][j]);
					/*
					 * if(Graphqueue.size()-1 !=0)
						g2[i][j]=Graphqueue.get(Graphqueue.size()-1).state[i][j];
					else
						g2[i][j]=Graphqueue.get(0).state[i][j];
					 */
				}
			}
			
		return g2;
	}
	
	
	public int calHeuristic(int[][] g) {
		// TODO Auto-generated method stub
		
		int cnt=0;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				//System.out.println(" this "+g[i][j]);
				if(g[i][j]!=goalState.state[i][j] && g[i][j]!=0)
					cnt++;
			}
		}
		
		return cnt;
	}

	

}
