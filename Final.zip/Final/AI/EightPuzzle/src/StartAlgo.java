import java.util.*;
import java.io.*;
import java.lang.*;


public class StartAlgo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
			CreateGraph cg =new CreateGraph();
			cg.genrateData();
			cg.goToAstar();
	}

}
