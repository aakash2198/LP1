from nltk.chat.util import Chat,reflections

pairs = [
		[
			r"Hi my name is(.*)",
			["Hi %1 ,how are you",]		
		],
		
		
		
		[
			r"What is your name",
			["My name is google",]

		],

		[
			r"What can you do for me",
			["I can show you information about Money",]

		],

		[
			r"quit",
			["Okay",]

		],

	]






def chatbot():	
	print("Booting..... Hey I'm your chat bot.You can ask me anything about money. (In ENGLISH ONLY)")
	chat=Chat(pairs,reflections)
	chat.converse()



if __name__ == "__main__":
	chatbot()
