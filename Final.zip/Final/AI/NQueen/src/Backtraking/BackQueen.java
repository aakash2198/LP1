package Backtraking;

import java.util.Scanner;

public class BackQueen {

	int N;
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BackQueen b = new BackQueen();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter queen size");
		int N=sc.nextInt();
		b.setN(N);
		b.solve();

	}

	public void solve() {
		// TODO Auto-generated method stub
		int block[][]=new int[N][N];
		
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				block[i][j]=0;
			}
		}
		
		if(finalSolve(block,0)==false)
		{
			System.out.println("Solution not exits");
		}
		
		
		display(block);
		
	}

	private void display(int[][] block) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				System.out.print(block[i][j]+" ");
			}
			System.out.println();
		}
		
	}

	private boolean finalSolve(int[][] block, int col) {
		// TODO Auto-generated method stub
		
		if(col>=N)
			return true;
		
		for(int i=0;i<N;i++)
		{
			if(isSafe(block,i,col))
			{
				block[i][col]=1;
				if(finalSolve(block, col+1))
				{
					return true;
				}
				block[i][col]=0;
			}
		}
		
		
		return false;
	}

	private boolean isSafe(int[][] block, int row, int col) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<col;i++)
		{
			if(block[row][i]==1)
				return false;
		}
		for(int i=row,j=col;i>=0 && j>=0 ;i--,j--)
		{
			if(block[i][j]==1)
				return false;
		}
		for(int i=row,j=col;i<N && j>=0 ;i++,j--)
		{
			if(block[i][j]==1)
				return false;
		}
		
		
		return true;
	}

	public void setN(int n) {
		// TODO Auto-generated method stub
		this.N= n;
		
	}

}
