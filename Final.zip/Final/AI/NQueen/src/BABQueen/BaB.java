package BABQueen;

import java.util.Scanner;

public class BaB {
	int N;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaB b = new BaB();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter queen size");
		int N=sc.nextInt();
		b.setN(N);
		b.solve();

	}

	private void solve() {
		// TODO Auto-generated method stub
		int board[][]=new int[N][N];
		
		boolean rowL[]=new boolean[N];
		boolean slashCodeL[]=new boolean[2*N-1];
		boolean BackSlashCodeL[]=new boolean[2*N-1];
		
		int slashCode[][]=new int[N][N];
		int backslashCode[][]=new int[N][N];
		
		for(int i=0;i<N;i++)
		{
			rowL[i]=false;
		}
		
		for(int i=0;i<((2*N)-1);i++)
		{
			slashCodeL[i]=false;
			BackSlashCodeL[i]=false;
		}
		
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				slashCode[i][j]=i+j;
				backslashCode[i][j]=i-j+(N-1);
				board[i][j]=0;
			}
		}
		
		if(finalSolve(board,0,rowL,slashCode,slashCodeL,backslashCode,BackSlashCodeL)==false)
		{
			System.out.println("Solution not found");
		}
		
		display(board);
		
		
	}

	private void display(int[][] board) {
		// TODO Auto-generated method stub
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				System.out.print(board[i][j]+" ");
			}
			System.out.println();
		}
		
	}

	private boolean finalSolve(int[][] board, int col, boolean[] rowL, int[][] slashCode, boolean[] slashCodeL,
			int[][] backslashCode, boolean[] backSlashCodeL) {
		// TODO Auto-generated method stub
		
		if(col>=N)
			return true;
		
		for(int i=0;i<N;i++)
		{
			if(isSafe(board,i,col,rowL,slashCode,slashCodeL,backslashCode,backSlashCodeL))
			{
				board[i][col]=1;
				rowL[i]=true;
				slashCodeL[slashCode[i][col]]=true;
				backSlashCodeL[backslashCode[i][col]]=true;
				
				if(finalSolve(board, col+1, rowL, slashCode, slashCodeL, backslashCode, backSlashCodeL))
				{
					return true;
				}
				
				board[i][col]=0;
				rowL[i]=false;
				slashCodeL[slashCode[i][col]]=false;
				backSlashCodeL[backslashCode[i][col]]=false;
			}
		}
		
		
		
		
		return false;
	}

	private boolean isSafe(int[][] board, int i, int col, boolean[] rowL, int[][] slashCode, boolean[] slashCodeL,
			int[][] backslashCode, boolean[] backSlashCodeL) {
		// TODO Auto-generated method stub
		
		if(rowL[i] || slashCodeL[slashCode[i][col]] || backSlashCodeL[backslashCode[i][col]])
			return false;
		
		return true;
	}

	private void setN(int n2) {
		// TODO Auto-generated method stub
		this.N=n2;
	}

}
