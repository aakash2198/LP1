package MyP;
import java.util.*;

public class HillClimb {
	Scanner sc=new Scanner(System.in);
	ArrayList<State> queue = new ArrayList<>();
	State StartState=new State();
	State GoalState=new State();
	
	public HillClimb() {
		// TODO Auto-generated constructor stub
		
		State StartState = new State();
		State GoalState = new State();
	}
	
	public void acceptData()
	{
		System.out.println("Enter start state ");
		
		for(int i=0;i<9;i++)
		{
			StartState.arr[i]=sc.nextInt();
		}
		
		System.out.println("Enter goal state ");
		
		for(int i=0;i<9;i++)
		{
			GoalState.arr[i]=sc.nextInt();
		}
		
	}
	
	public int calHeuristic(State S1)
	{
		int a=0;
		
		for(int i=0;i<9;i++)
		{
			if(S1.arr[i]!=GoalState.arr[i])
				a++;
		}
		
		
		return a;
		
	}
	
	public int Lowest()
	{
		int i=0;
		int min=9999;
		
		for(int j=0;j<queue.size();j++)
		{
			if(calHeuristic(queue.get(j)) <min )
			{
				min = calHeuristic(queue.get(j));
				i=j;
			}
		}
		
		
		return i;
	}
	
	public void Move(State s1)
	{
		int p = findPos(s1);
		queue.clear();
		
		State temp1=new State(s1);
		if(p%3!=0)
		{
			temp1.arr[p]=temp1.arr[p-1];
			temp1.arr[p-1]=0;
			temp1.h = calHeuristic(temp1);
			queue.add(temp1);
		}
		
		
		State temp2=new State(s1);
		if(p%3!=2)
		{
			temp2.arr[p]=temp2.arr[p+1];
			temp2.arr[p+1]=0;
			temp2.h = calHeuristic(temp2);
			queue.add(temp2);
		}
		
		
		State temp3=new State(s1);
		if(p>2 && p<9)
		{
			temp3.arr[p]=temp3.arr[p-3];
			temp3.arr[p-3]=0;
			temp3.h = calHeuristic(temp3);
			queue.add(temp3);
		}
		
		
		State temp4=new State(s1);
		if(p<6)
		{
			temp4.arr[p]=temp4.arr[p+3];
			temp4.arr[p+3]=0;
			temp4.h = calHeuristic(temp4);
			queue.add(temp4);
		}
	}
	
	private int findPos(State s1) {
		// TODO Auto-generated method stub
		
		for(int i=0;i<9;i++)
		{
			if(s1.arr[i]==0)
				return i;
		}
		
		return -1;
	}

	public void mainAlgo()
	{
		State s1,s2;
		s1=StartState;
		Display(StartState);
		
		Move(s1);
		int index = Lowest();
		s2=queue.get(index);
		
		while(calHeuristic(s2)<calHeuristic(s1))
		{
			Display(s2);
			s1=s2;
			
			Move(s1);
			 index = Lowest();
			s2=queue.get(index);
			
		}
		
	}
	

	public void Display(State startState2) {
		// TODO Auto-generated method stub
		int k=0;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(startState2.arr[k++]+" ");
			}
			System.out.println();
		}
		
		System.out.println();
		System.out.println();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HillClimb h1=new HillClimb();
		h1.acceptData();
		h1.mainAlgo();

	}

}
