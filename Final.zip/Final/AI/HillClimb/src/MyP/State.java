package MyP;

public class State {
	int arr[]=new int[9];
	int h;
	
	public State(State s1)
	{
		int arr[]=new int[9];
		for(int i=0;i<9;i++)
		{
			this.arr[i]=s1.arr[i];
		}
	}
	
	public State()
	{
		
		h=0;
	}

}
