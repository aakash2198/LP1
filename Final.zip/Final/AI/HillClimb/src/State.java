import java.io.*;
import java.util.*;
import java.lang.*;

public class State {
	int heurastic;
	int arr[]=new int[9];
	
	public State(State s1)
	{
		
				for(int i=0;i<9;i++)
				{
					this.arr[i]=s1.arr[i];
				}
	}
	
	public State()
	{
		heurastic=0;
	}

}
