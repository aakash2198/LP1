import java.io.*;
import java.util.*;
import java.lang.*;
public class HillAlgo {
	Scanner sc=new Scanner(System.in);
	List<State> queue = new ArrayList<State>();
	State startS;
	State goalS;
	
	public HillAlgo() {
		// TODO Auto-generated constructor stub
		startS = new State();
		goalS = new State();
	}
	
	public void display(State s)
	{
		System.out.println();
		System.out.println();
		int k=0;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(s.arr[k++]+" ");
			}
			System.out.println();
		}
		
		
	}
	
	public void acceptData() {
		// TODO Auto-generated method stub
		System.out.println("Enter Start State");
		for(int i=0;i<9;i++)
		{
			startS.arr[i] = sc.nextInt();
		}
		
		
		System.out.println("Enter Goal State");
		for(int i=0;i<9;i++)
		{
			goalS.arr[i] = sc.nextInt();
		}
		
	}
	
	public int calculateHeuristic(State s)
	{
		int x=0;
		
		for(int i=0;i<9;i++)
		{
			if(s.arr[i]!=goalS.arr[i])
				x++;
		}
		
		
		return x;
	}
	
	
	public void move(State s)
	{
		int p = blackPos(s);
		queue.clear();
		
		State temp =new State(s);
		if(p%3!=0)
		{
			temp.arr[p]=temp.arr[p-1];
			temp.arr[p-1]=0;
			temp.heurastic=calculateHeuristic(temp);
			//display(temp);
			queue.add(temp);
		}
		
		State temp2 =new State(s);
		if(p%3!=2)
		{
			temp2.arr[p]=temp2.arr[p+1];
			temp2.arr[p+1]=0;
			temp2.heurastic=calculateHeuristic(temp2);
			//display(temp2);
			queue.add(temp2);
		}
		
		State temp3 =new State(s);
		if(p>2 && p<9)
		{
			temp3.arr[p]=temp3.arr[p-3];
			temp3.arr[p-3]=0;
			temp3.heurastic=calculateHeuristic(temp3);
			//display(temp3);
			queue.add(temp3);
		}
		
		State temp4 =new State(s);
		if(p<6)
		{
			temp4.arr[p]=temp4.arr[p+3];
			temp4.arr[p+3]=0;
			temp4.heurastic=calculateHeuristic(temp4);
			//display(temp4);
			queue.add(temp4);
		}
	}
	
	
	
	public int blackPos(State s) {
		// TODO Auto-generated method stub
			
			for(int i=0;i<9;i++)
			{
				if(s.arr[i]==0)
					return i;
			}
			
		return -1;
	}

	public void algo()
	{
		State s1,s2;
		s1=startS;
		display(s1);
		
		move(s1);
		int lowest = calLowest();
		//System.out.println("low "+lowest);
		s2=queue.get(lowest);
		//System.out.println("S2 : ");
		//display(s2);
		
		while(calculateHeuristic(s2) < calculateHeuristic(s1))     // imp for you
		{
			System.out.println("Inside");
			display(s2);
			s1=s2;
			move(s1);
			lowest = calLowest();
			s2=queue.get(lowest);
		}
		
		
		
	}
	
	
	

	private int calLowest() {
		// TODO Auto-generated method stub
		int i=-1;
		
		int min=9000;
		for(int j=0;j<queue.size();j++)
		{
			if(queue.get(j).heurastic <min)
			{
				min=queue.get(j).heurastic;
				i=j;
			}
		}
		
		
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HillAlgo h1 = new HillAlgo();
		h1.acceptData();
		h1.algo();
		
		
		
	}

	

}
