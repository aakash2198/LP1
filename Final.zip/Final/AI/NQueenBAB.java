import java.util.*;


class NQueenBAB
{

int N;
	
public void setN(int N)
{
this.N=N;
}



public void printMatrix(int board[][])
{
for(int i=0;i<N;i++)
	{
		for(int j=0;j<N;j++)
		{
			System.out.print(" "+board[i][j]+" ");
		}
		System.out.println();
	}

}


public boolean isSafe(int board[][] , int row, int col ,boolean rowlookup[] ,int slashcode[][],int  backslashcode[][],boolean slashcodelookup[], boolean  backslashcodelookup[])
{
	if(rowlookup[row] || slashcodelookup[slashcode[row][col]] || backslashcodelookup[backslashcode[row][col]] )
		return false;
	
return true;
}

public boolean finalSolve(int board[][] , int col , boolean rowlookup[] ,int slashcode[][],int  backslashcode[][],boolean slashcodelookup[], boolean  backslashcodelookup[] )
{
	if(col>=N)
		return true;
	
	for(int i=0;i<N;i++)
	{
		if(isSafe(board,i,col,rowlookup ,slashcode,backslashcode,slashcodelookup,backslashcodelookup))
		{
			board[i][col]=1;
			rowlookup[i]=true;
			slashcodelookup[slashcode[i][col]] = true;
			backslashcodelookup[backslashcode[i][col]] = true;
			
			if(finalSolve(board,col+1,rowlookup ,slashcode,backslashcode,slashcodelookup,backslashcodelookup))
			{
				return true;
			}
			board[i][col]=0;
			rowlookup[i]=false;
			slashcodelookup[slashcode[i][col]] = false;
			backslashcodelookup[backslashcode[i][col]] = false;
		}


	}

	return false;

}



public void solve()
{
int board[][]=new int[N][N];

boolean rowlookup[]=new boolean[N];
int slashcode[][]=new int[N][N];
int backslashcode[][]=new int[N][N];

boolean slashcodelookup[]=new boolean[2*N-1];
boolean backslashcodelookup[]=new boolean[2*N-1];

for(int i=0;i<((2*N)-1);i++)
{
	slashcodelookup[i]=false;
	backslashcodelookup[i]=false;
}

for(int i=0;i<N;i++)
{
	rowlookup[i]=false;
}

for(int i=0;i<N;i++)
{
	for(int j=0;j<N;j++)
	{
		slashcode[i][j]=i+j;
		backslashcode[i][j]=i-j+(N-1);
		board[i][j]=0;
	}

}

if(finalSolve(board , 0 , rowlookup ,slashcode,backslashcode,slashcodelookup,backslashcodelookup)==false)
{	
	System.out.println("Solution not possible");
}
	
	printMatrix(board);


}

public static void main(String[] args)
{
	NQueenBAB q = new NQueenBAB();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter number of Queens");
	int n = sc.nextInt();
	q.setN(n);
	q.solve();

}


}
